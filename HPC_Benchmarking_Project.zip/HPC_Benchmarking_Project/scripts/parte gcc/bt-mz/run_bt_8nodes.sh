#!/bin/bash
#SBATCH --job-name=run_bt_8nodes
#SBATCH --output=bt-mz_%j.out
#SBATCH --error=bt-mz_%j.err
#SBATCH --nodes=8
#SBATCH --ntasks=896
#SBATCH --cpus-per-task=1
#SBATCH --qos=gp_debug
#SBATCH --account=nct_321
#SBATCH --constraint=perfparanoid
#SBATCH --ear=on
#SBATCH --ear-user-db=bt_ear.csv

export NAS_PATH=$HOME/NPB3.4.3-MZ/NPB3.4-MZ-MPI/bin
export INPUT_FILE=./inputbt-mz.data
export DIR_BASE=$HOME/NPB3.4.3-MZ/scripts/outputs/bt-mz/8nodes/INT2

module purge
module load bsc
module load intel
module load impi

#echo "===== Configuración MPI pura (896x1) ====="
#for i in {1..3}; do
#    echo "========== [MPI] Ejecución $i =========="
#    srun --ntasks=896 --cpus-per-task=1 $NAS_PATH/bt-mz.D.x < $INPUT_FILE
#done

#echo "===== Configuración OpenMP pura (8x112) ====="
#export OMP_NUM_THREADS=112
#for i in {1..3}; do
#    echo "--- Ejecución $i ---"
#    srun --ntasks=8 --cpus-per-task=112 $NAS_PATH/bt-mz.D.x < $INPUT_FILE
#done

#echo "===== Configuración intermedia (112x8) ====="
#export OMP_NUM_THREADS=8
#for i in {1..3}; do
#    echo "--- Ejecución $i ---"
#    srun --ntasks=112 --cpus-per-task=8 $NAS_PATH/bt-mz.D.x < $INPUT_FILE
#done

echo "===== Configuración intermedia 2 (56x16) ====="
export OMP_NUM_THREADS=16
for i in {1..3}; do
    echo "--- Ejecución $i ---"
    srun --ntasks=56 --cpus-per-task=16 $NAS_PATH/bt-mz.D.x < $INPUT_FILE
done

echo "===== Moviendo .csv a carpeta de resultados ====="
mkdir -p $DIR_BASE
timestamp=$(date +%s)
for f in bt_ear.csv*; do
    mv "$f" "$DIR_BASE/${f%.csv}_$timestamp.csv"
done

mv bt-mz_${SLURM_JOB_ID}.out $DIR_BASE/bt-mz_8nodes_${SLURM_JOB_ID}.out
mv bt-mz_${SLURM_JOB_ID}.err $DIR_BASE/bt-mz_8nodes_${SLURM_JOB_ID}.err

