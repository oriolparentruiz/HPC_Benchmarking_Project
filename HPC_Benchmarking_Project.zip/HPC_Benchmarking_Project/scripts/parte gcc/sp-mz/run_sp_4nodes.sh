#!/bin/bash
#SBATCH --job-name=run_sp_4nodes
#SBATCH --output=sp-mz_%j.out
#SBATCH --error=sp-mz_%j.err
#SBATCH --nodes=4
#SBATCH --ntasks=448
#SBATCH --cpus-per-task=1
#SBATCH --qos=gp_debug
#SBATCH --account=nct_321
#SBATCH --constraint=perfparanoid
#SBATCH --ear=on
#SBATCH --ear-user-db=sp_ear.csv

export NAS_PATH=$HOME/NPB3.4.3-MZ/NPB3.4-MZ-MPI/bin
export INPUT_FILE=./inputsp-mz.data
export DIR_BASE=$HOME/NPB3.4.3-MZ/scripts/outputs/sp-mz/4nodes/MPI

# module load bsc gcc openmpi
module purge
module load bsc
module load intel
module load impi
	
echo "===== Configuración MPI pura (448x1) ====="
for i in {1..3}; do
    echo "--- Ejecución $i ---"
    srun --ntasks=448 --cpus-per-task=1 $NAS_PATH/sp-mz.D.x < $INPUT_FILE
done

#echo "===== Configuración OpenMP pura (4x112) ====="
#export OMP_NUM_THREADS=112
#for i in {1..3}; do
#    echo "--- Ejecución $i ---"
#    srun --ntasks=4 --cpus-per-task=112 $NAS_PATH/sp-mz.D.x < $INPUT_FILE
#done

#echo "===== Configuración intermedia1 (56x8) ====="
#export OMP_NUM_THREADS=8
#for i in {1..3}; do
#    echo "--- Ejecución $i ---"
#    srun --ntasks=56 --cpus-per-task=8 $NAS_PATH/sp-mz.D.x < $INPUT_FILE
#done

#echo "===== Configuración intermedia 2 (28x16) ====="
#export OMP_NUM_THREADS=16
#for i in {1..3}; do
#    echo "--- Ejecución $i ---"
#    srun --ntasks=28 --cpus-per-task=16 $NAS_PATH/sp-mz.D.x < $INPUT_FILE
#done

echo "===== Moviendo ficheros a carpeta de resultados ====="
mkdir -p $DIR_BASE
timestamp=$(date +%s)
for f in sp_ear.csv*; do
    mv "$f" "$DIR_BASE/${f%.csv}_$timestamp.csv"
done

mv sp-mz_${SLURM_JOB_ID}.out $DIR_BASE/sp-mz_4nodos_${SLURM_JOB_ID}.out
mv sp-mz_${SLURM_JOB_ID}.err $DIR_BASE/sp-mz_4nodos_${SLURM_JOB_ID}.err

